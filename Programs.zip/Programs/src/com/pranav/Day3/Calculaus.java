package com.pranav.Day3;

import java.util.Scanner;

class D
{
	public double Far()
	{
		Scanner f=new Scanner(System.in);
		System.out.println("Enter the Celsius to conver in Fahrenheit:");
		double n=f.nextFloat();
		double r=(n*1.8)+32;
		return r;
	}
	public double Cell()
	{
		Scanner f=new Scanner(System.in);
		System.out.println("Enter the Fahrenheit to conver in Celsius:");
		double n=f.nextFloat();
		double r=(n-32)*0.5556;
		return r;
	}
}
public class Calculaus
{
	public static void main(String args[])
	{
		D d= new D();
		Scanner m=new Scanner(System.in);
		System.out.println("Enter Your Choice:");
		int ch=m.nextInt();
		switch(ch)
		{
			case 1:
				System.out.println(d.Cell());
				break;
			case 2:
				System.out.println(d.Far());
				break;
			default:
				System.out.println("Entered Wrong Choice");
		}
	}
}