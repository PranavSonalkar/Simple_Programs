package com.pranav.Day3;
class Calci{
	public float minus(float num1,float num2,float num3)
	{
		float r=num1-num2-num3;
		return r;
		
	}
	public double div(double n1,double n2)
	{
		double r=n1/n2;
		return r;
	}
	public int multi(int x,int y) 
	{
		int r=x*y;
		return r;
	}
}
public class Substraction {
	public static void  main(String args[])
	{
		Calci cals= new Calci();
		
		System.out.println("The Substraction of numbers="+cals.minus(90, 34, 50));
		System.out.println("The Division of numbers="+cals.div(5, 9));
		System.out.println("The Multipliction of numbers="+cals.multi(67, 80));
	}

}
