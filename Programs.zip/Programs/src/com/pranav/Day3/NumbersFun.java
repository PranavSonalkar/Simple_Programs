package com.pranav.Day3;

import java.util.Scanner;
class fun
{
	public void range()
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		for(int i=0;i<=n;i++)
			System.out.println(i);
			
	}
	public void EO()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number");
		int n=s.nextInt();
		for(int r=0;r<=n;r++)
			if(r%2==0)
				System.out.println("Number"+r+" is Even");
			else
				System.out.println("Number"+r+" is Odd");
	}
	public void Fact()
	{
		 int i,fact=1;  
		  int number=5;//It is the number to calculate factorial    
		  for(i=1;i<=number;i++){    
		      fact=fact*i;    
		      System.out.println("Factorial of"+number+"is: "+fact);	
		  }
}
public class NumbersFun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		fun t=new fun();
		Scanner ds=new Scanner(System.in);
		int f=ds.nextInt();
		switch(f)
		{
		case 1:
			t.range();
			break;
		case 2:
			t.EO();
			break;
		case 3:
			t.Fact();
			break;
			
		default:
			
		}

		}
	}
}



