package com.pranav.Day3;
import java.util.*;
class Accesseries{
	public void Whatsapp()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Choice:");
		int ch=s.nextInt();
		switch(ch)
		{
			case 1:
				System.out.println("See Status of contacts...!");
				break;
			case 2:
				System.out.println("Save a Contact...!");
				int no=s.nextInt();
				String name=s.next();
				break;
			case 3:
				System.out.println("Send Messages...!");
				break;
			default:
				System.out.println("Exit the app...!");
		}
	}
	public void Facebook()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Choice:");
		int ch=s.nextInt();
		switch(ch)
		{
			case 1:
				System.out.println("See Status of Friends...!");
				break;
			case 2:
				System.out.println("Save a Send Friend Request...!");
				String name=s.next();
				System.out.println("Request is sended...!");
				break;
			case 3:
				System.out.println("Send Messages...!");
				break;
			case 4:
				System.out.println("Friend 2nd Request...!");
				boolean flage=s.hasNextBoolean();
				if(flage==true) 
					System.out.println("Accepte the Request...!");
				else
					System.out.println("Decline the Request...!");
				break;
			default:
				System.out.println("Exit the app...!");
		}
	}
	public void Instagram()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Choice:");
		int ch=s.nextInt();
		switch(ch)
		{
			case 1:
				System.out.println("See Status of Friends...!");
				break;
			case 2:
				System.out.println("Save a Send Friend Request...!");
				String name=s.next();
				System.out.println("Request is sended...!");
				break;
			case 3:
				System.out.println("Send Messages...!");
				break;
			case 4:
				System.out.println("Friend 2nd Request...!");
				boolean flage=s.hasNextBoolean();
				if(flage==true) 
					System.out.println("Accepte the Request...!");
				else
					System.out.println("Decline the Request...!");
				break;
			default:
				System.out.println("Exit the app...!");
		}	
	}
}
public class Mobile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Accesseries ac=new Accesseries();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Choice:");
		int ch=s.nextInt();
		switch(ch)
		{
		case 1:
			System.out.println("Open the Whatsapp.");
			ac.Whatsapp();
			break;
		case 2:
			System.out.println("Open the Facebook.");
			ac.Facebook();
			break;
		case 3:
			System.out.println("Open the Instagram.");
			ac.Instagram();
			break;
		default:
			System.out.println("Shut the Phone.");
		}

	}

}
