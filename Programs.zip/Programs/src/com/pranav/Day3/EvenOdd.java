package com.pranav.Day3;

import java.util.Scanner;

class Pranav
{
	public int math()
	{
		
		Scanner u= new Scanner(System.in);
		System.out.println("Enter the value for Evaluation:");
		int n=u.nextInt();
		if(n%2==0)
		{
			System.out.println("The number is Even...");
			return 1;
		}
		else
		{
			System.out.println("The number is not Even...");
			return 0;
		}
		
	}
}
public class EvenOdd 
{
	public static void main(String args[])
	{
		Pranav p=new Pranav();
		System.out.println("Answer="+p.math());
	}

}
