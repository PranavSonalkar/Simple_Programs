package com.pranav.Day3;

import java.util.Scanner;

class Trignometry{
	public void Tiangle() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Base and Hieght of Triangle:");
		double b=sc.nextDouble(),h=sc.nextDouble();
		double res=0.5*b*h;
		System.out.println(res);
	}
	public void Reactangle() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Base and Length of Reactangle:");
		double b=sc.nextDouble(),l=sc.nextDouble();
		double res=2*(b+l);
		System.out.println(res);
	}
	public void Square() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Side of Square:");
		double s=sc.nextDouble();
		double res=s*s;
		System.out.println(res);
	}
	public void Pentagon()
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Perimeter and Apothem of Pentagon:");
		double p=sc.nextDouble(),a=sc.nextDouble();
		double res=0.5*(p*a);
		System.out.println(res);
	}
	public void Hexagon()
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Perimeter and Apothem of Hexagon:");
		double p=sc.nextDouble(),a=sc.nextDouble();
		double res=0.5*(p*a);
		System.out.println(res);
	}
	
}

public class Mathmatics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Trignometry t=new Trignometry();
		t.Tiangle();
		t.Reactangle();
		t.Square();
		t.Pentagon();
		t.Hexagon();
	}

}
