package com.pranav.Day3;
/**
 * Calculator
 */
class Calculator{
	public int add(int n1,int n2)
	{
		int r=n1+n2;
		return r;
	}
}
public class Demo{
    public static void main(String[] args) {
    	int num1=7,num2=3;
    	Calculator cals = new Calculator();
    	
  	int result=cals.add(num1,num2);
   	System.out.println("Addtion is ="+result);
        
    }
}