package com.pranav.Day2;

public class Demo1 {
    public static void main(String []args){
        int x=18;
        if(x>10 && x<=20)
        {
            System.out.println("Hello");
        }
        else{
            System.out.println("Bye");
        }
    }
    
}
