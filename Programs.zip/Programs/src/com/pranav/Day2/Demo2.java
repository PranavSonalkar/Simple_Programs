package com.pranav.Day2;

public class Demo2 {
    public static void main(String[] args) {
        int x=8,y=17,z=9;
        if (x>y && x>z) {
            System.out.println(x);
        }        
        else if (y>z) {
            System.out.println(y);
        } else {
            System.out.println(z);
        }
    }
}
