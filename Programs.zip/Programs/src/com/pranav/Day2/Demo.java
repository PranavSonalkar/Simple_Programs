package com.pranav.Day2;

class Demo{
    public static void main(String d[]){
    int x=8,y=9,a=5,b=10;
    boolean result=x<y;
    result=x>y;
    result=x<y && a<b;
    result= x<y || a>b;
    System.out.println(!result);
    if(x<y){
        System.out.println(x);
        System.out.println("Thank you");
    }
    else
        System.out.println(y);
    }
}