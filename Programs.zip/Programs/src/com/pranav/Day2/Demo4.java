package com.pranav.Day2;

import java.util.Scanner;

class Demo4{
    public static void main(String[] args) {
        int a;
        Scanner sd= new Scanner(System.in);
        System.out.println("Enter the Value:");
        a=sd.nextInt();
        System.out.println(a);
          
    }
}