package com.pranav.Day1;

//Type conversion of Types
class conversion{
    public static void main(String args[])
    {
        int c=12;
        byte k=(byte)c;
        
        //Type prmotion
        byte a=10;
        byte b=30;
        int result =a*b;
        System.out.println(result);
    }
}