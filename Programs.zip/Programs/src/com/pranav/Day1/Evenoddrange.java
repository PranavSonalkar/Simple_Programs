package com.pranav.Day1;

import java.util.Scanner;

//import java.util.Scanner.*;
class Evenoddrange
{
    public static void main(String a[])
    {
        Scanner v = new Scanner(System.in);
        System.out.println("Enter the number:");
       int n=v.nextInt();
        for(int i=1;i<=n;i++){
            if(i % 2==0)
                System.out.println("The number"+ i +" is Even");
            else
                System.out.println("The number"+ i +" is Odd");
        }
    }
}