package com.pranav.Day1;


class Addition{
    public static void main(String a[])
    {
        int num1 = 3;
        int num2 = 5;
        System.out.println(num1+num2);
        //All type representation
        int num=9;
        byte by =127;
        short sh=558;
        long l =5854l;
        float marks =6.5f; 
        double d=89.5;
        char c= 'p';
        boolean u=true;
        //binary number
        int gh=0b101;
        System.out.println(gh);
        //hexa number
        int hx=0x7E;
        System.out.println(hx);

        int ui=1_00_00_000;
        System.out.println(ui);

         //character
        char ch='a';
        ch++;
        System.out.println(ch);

    }
}