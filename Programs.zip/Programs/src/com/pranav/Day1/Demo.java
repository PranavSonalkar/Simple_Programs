package com.pranav.Day1;

class Demo{
    public static void main(String args[])
    {
        int n1=7;
      int n2=5;

        int result =n1%n2;
        System.out.println(result);
    }
}